## Simulating a Null model to compare to AICc
# Load necessary packages
library(phytools)
library(mvMORPH)
library(paleotree)
library(geomorph)
library(Arothron)
library(paleomorph)
library(phytools) 
library(ape)
library(geiger)
library(tibble)
library(dispRity)
library(RRphylo)

setwd("D:/Lang - GMM Endocast Project/Fossil Paper/Fossil GM Data")

###### Load Files ###### 
	Classifier <- read.csv("EG-GMM-Fossil-Classifier-Good.csv") 	# classifier in the sequence of the phylogeny
	spnames <- read.csv("Spnames.csv")								# names in the order they occur in the folder with landmarks  
	coordsraw <- read.amira.dir("EG_Landmarks_Good",42)				# read raw coordinate data from file
	coordsraw[3,,98] <- NA		# removing landmark 3 for Notharctus as the lm is missing
	coordsraw[28,,97] <- NA		# removing landmark 28 for Necrolemur as the lm is missing
	omit <- c(5,9,14,23,25,26,37)									# removing duplicate landmarks
	coords.all <-coordsraw[-omit,,]
	
###### Estimate Missing Landmarks ######
	coords.all <-estimate.missing(coords.all, method = "TPS")

###### Procurstes Transformation/Data set up ######	
	sliders <- rbind(define.sliders(25:30), define.sliders(30:35))		# designating sliding landmarks within dataset for curve 2
	Y.gpa <- gpagen(coords.all, curves = sliders)	
	dimnames(Y.gpa$coords)[[3]] <- gsub (".txt", "", spnames$Species)	# assign species names in the same format (but not sequence) as in the tree. Both dimnames and spnames shoule be alphabetized

## Setting up Tree ##
	mytree1 <- read.nexus("avg_tree_manual_mean-1000.nex")	
	treeage <- tree.age(mytree1, order="past", fossil=TRUE, digits=3)		# ages of the nodes and the root look correct 

	tipAges <- cbind(c("Ptilocercus_lowii","Ochotona_collaris"), c(0,0))	# calcualted time between these two taxa to get root age (because they are extant time = 0)
	mytree <- setRootAge(mytree1,tipAges)									# set root age (78.10585)
	mytree$root.time	
	
	all(mytree$tip.label == dimnames(Y.gpa$coords)[[3]])	# verify if names match exactly (in order)
	all(mytree$tip.label %in% dimnames(Y.gpa$coords)[[3]])	# verify if all your shape objects are in the phylogeny 
	all(dimnames(Y.gpa$coords)[[3]] %in% mytree$tip.label)	# if all tips of the tree are in your shape dataset
	match(dimnames(Y.gpa$coords)[[3]], mytree$tip.label)	# what is the order that need to be rearranged?

	coords <- Y.gpa$coords[,,match(mytree$tip.label, dimnames(Y.gpa$coords) [[3]] ) ] #rearrange data

	all(mytree$tip.label == dimnames(coords)[[3]])			# verify if names match exactly (in order)
	all(mytree$tip.label %in% dimnames(Y.gpa$coords)[[3]])	# verify if all your shape objects are on the phylogeny 
	all(dimnames(Y.gpa$coords)[[3]] %in% mytree$tip.label)	# if all tips of the tree are in your shape dataset	
	
	names(Y.gpa$Csize) = spnames$Species					# Labeling centroid size 
	csize <- Y.gpa$Csize[match(mytree$tip.label,names(Y.gpa$Csize))]	# ordering centroid size
	
###### Dataframe ######	
	GDF <- geomorph.data.frame(landmarks = coords, 
		species = Classifier$Species, 
		order = Classifier$Order,
		HS = Classifier$Hapstrep,
		pcl = Classifier$PriClad,
		rcl = Classifier$RodClad,
		subgroup = Classifier$Subgroup, 	
		figure = Classifier$Figure, 
		status = Classifier$Status,
		csize = csize
		)

###### PCA ######
	PCA <- gm.prcomp(GDF$landmarks)

## Making the data matrix ##	
	PCA_dtt<-as.data.frame(PCA$x)
	PCA_dtt<-PCA_dtt[order(rownames(PCA_dtt)),]		# puts data into disparity matrix
	PCA_dtt<-add_column(PCA_dtt, species = spnames$Species)
	mPCA<-PCA_dtt[match(mytree$tip.label,rownames(PCA_dtt)),][1:4] # making a PCA file which matches sequence in phylogeny - should already be matching 
	mtx<-as.matrix(mPCA)

## Tree with regimes mapped onto the branches ##
	library(phytools)

	regimes <- setNames(GDF$order, GDF$species)  # clade assignments for each species
	tree_map <- make.simmap(mytree, regimes, model = "ER", nsim = 1) #create tree with mapped clades
	plotSimmap(tree_map)

## simulations BATCH 1
	nsim    <- 25                              # Number of simulated datasets - done is batches as these can take a long time to run
	ntips   <- length(mytree$tip.label)        # Number of species
	ntraits <- ncol(mtx)                       # Number of traits

# Prepare storage
	sim_results_batch1 <- vector("list", nsim)

	for (i in 1:nsim) {
		cat("****************Running simulation:", i, "\n")

# Simulate under BM1
	sim_data <- mvSIM(mytree,
		model = "BM1",
		param = list(sigma = diag(ntraits), ntraits = ntraits),
		nsim  = 1)

# Fit models
	fit_bm  <- mvBM( mytree, sim_data, model = "BM1")
	fit_ou1 <- mvOU( mytree, sim_data, model = "OU1")
	fit_oum <- mvOU(tree_map, sim_data, model = "OUM",
		method = "sparse",
		param  = list(decomp = "cholesky", root = TRUE))
	fit_eb  <- mvEB( mytree, sim_data)

# Extract α and θ
	alpha_ou1 <- diag(fit_ou1$alpha)
	theta_ou1 <- fit_ou1$theta
	alpha_oum <- diag(fit_oum$alpha)
	theta_oum <- fit_oum$theta

# Store everything in a single list element
	sim_results_batch1[[i]] <- list(
		AICc = data.frame(
		BM  = fit_bm$AICc,
		OU1 = fit_ou1$AICc,
		OUM = fit_oum$AICc,
		EB  = fit_eb$AICc
	),
	alpha = list(
		OU1 = alpha_ou1,
		OUM = alpha_oum
	),
	theta = list(
		OU1 = theta_ou1,
		OUM = theta_oum
	)
	)
	}

# Save to disk
saveRDS(sim_results_batch1, file = "sim_results_batch1.rds")







































## simulations BATCH 1
#
	nsim    <- 100							# Number of simulated datasets
	ntips   <- length(mytree$tip.label)		# Number of species
	ntraits <- ncol(mtx)					# Number of traits

# Prepare storage
	for (i in 1:nsim) {
	  cat("Running simulation:", i, "\n")

# 1. Simulate under BM1
	sim_data <- mvSIM(mytree,
		model = "BM1",
		param = list(sigma = diag(ntraits), ntraits = ntraits),
		nsim  = 1)

# 2. Fit models
	fit_bm  <- mvBM( mytree, sim_data, model = "BM1")
	fit_ou1 <- mvOU( mytree, sim_data, model = "OU1")
	fit_oum <- mvOU(tree_map, sim_data, model = "OUM", method = "sparse",param  = list(decomp = "cholesky", root = TRUE))
	fit_eb  <- mvEB( mytree, sim_data)

# 3. Extract α and θ
	alpha_ou1 <- diag(fit_ou1$alpha)
	theta_ou1 <- fit_ou1$theta
	alpha_oum <- diag(fit_oum$alpha)
	theta_oum <- fit_oum$theta

# 4. Store everything in a single list element
	sim_results_batch2[[i]] <- list(
		AICc = data.frame(
			BM  = fit_bm$AICc,
			OU1 = fit_ou1$AICc,
			OUM = fit_oum$AICc,
			EB  = fit_eb$AICc),
		alpha = list(
			OU1 = alpha_ou1,
			OUM = alpha_oum),
			theta = list(
			OU1 = theta_ou1,
			OUM = theta_oum		)
		)
	}

# 5. Save to disk
saveRDS(sim_results_batch1, file = "sim_results_batch1.rds")

