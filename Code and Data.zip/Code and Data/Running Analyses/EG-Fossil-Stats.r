library(paleotree)
library(geomorph)
library(Arothron)
library(paleomorph)
library(phytools) 
library(ape)
library(geiger)
library(tibble)
library(dispRity)
library(RRphylo)
library(mvMORPH)

setwd("D:/Lang - GMM Endocast Project/Fossil Paper/Fossil GM Data")

## LOAD FILEs ## 
	Classifier <- read.csv("EG-GMM-Fossil-Classifier.csv") 	# classifier in the sequence of the phylogeny
	spnames <- read.csv("Spnames.csv")								# names in the order they occur in the folder with landmarks  
	coordsraw <- read.amira.dir("EG_Landmarks_Good",42)				# read raw coordinate data from file
	coordsraw[3,,98] <- NA		# removing landmark 3 for Notharctus as the lm is missing
	coordsraw[28,,97] <- NA		# removing landmark 28 for Necrolemur as the lm is missing
	omit <- c(5,9,14,23,25,26,37)									# removing duplicate landmarks
	coords.all <-coordsraw[-omit,,]
	
## Estimate Missing Landmarks ##
	coords.all <-estimate.missing(coords.all, method = "TPS")

## Procurstes Transformation/Data set up ##	
	sliders <- rbind(define.sliders(25:30), define.sliders(30:35))		# designating sliding landmarks within dataset for curve 2
	Y.gpa <- gpagen(coords.all, curves = sliders)	
	dimnames(Y.gpa$coords)[[3]] <- gsub (".txt", "", spnames$Species)	# assign species names in the same format (but not sequence) as in the tree. Both dimnames and spnames shoule be alphabetized

## Setting up Tree ##
	mytree1 <- read.nexus("avg_tree_manual_mean-1000.nex")	
	treeage <- tree.age(mytree1, order="past", fossil=TRUE, digits=3)		# ages of the nodes and the root look correct 

	tipAges <- cbind(c("Ptilocercus_lowii","Ochotona_collaris"), c(0,0))	# calcualted time between these two taxa to get root age (because they are extant time = 0)
	mytree <- setRootAge(mytree1,tipAges)									# set root age (78.10585)
	mytree$root.time	
	
	all(mytree$tip.label == dimnames(Y.gpa$coords)[[3]])	# verify if names match exactly (in order)
	all(mytree$tip.label %in% dimnames(Y.gpa$coords)[[3]])	# verify if all your shape objects are in the phylogeny 
	all(dimnames(Y.gpa$coords)[[3]] %in% mytree$tip.label)	# if all tips of the tree are in your shape dataset
	match(dimnames(Y.gpa$coords)[[3]], mytree$tip.label)	# what is the order that need to be rearranged?

	coords <- Y.gpa$coords[,,match(mytree$tip.label, dimnames(Y.gpa$coords) [[3]] ) ] #rearrange data

	all(mytree$tip.label == dimnames(coords)[[3]])			# verify if names match exactly (in order - should be TRUE)
	all(mytree$tip.label %in% dimnames(Y.gpa$coords)[[3]])	# verify if all your shape objects are on the phylogeny (should be TRUE)
	all(dimnames(Y.gpa$coords)[[3]] %in% mytree$tip.label)	# if all tips of the tree are in your shape dataset	(should be TRUE)
	
	names(Y.gpa$Csize) = spnames$Species					# Labeling centroid size 
	csize <- Y.gpa$Csize[match(mytree$tip.label,names(Y.gpa$Csize))]	# ordering centroid size

## Dataframe ##	
	GDF <- geomorph.data.frame(landmarks = coords, 
		species = Classifier$Species, 
		order = Classifier$Order,
		HS = Classifier$Hapstrep,
		pcl = Classifier$PriClad,
		rcl = Classifier$RodClad,
		subgroup = Classifier$Subgroup, 	
		figure = Classifier$Figure, 
		status = Classifier$Status,
		csize = csize
		)

## Setting up data for phylogenetic and other analyses ##
	lm.lag <- GDF$landmarks[ , , GDF$order == "Lagomorpha"]		# seperate coordinates from common Y.gpa for each clade of interest 
	lm.ple <- GDF$landmarks[ , , GDF$pcl == "Plesiadapiformes"]
	lm.ste <- GDF$landmarks[ , , GDF$pcl == "Stem_Glires"]
	lm.ant <- GDF$landmarks[ , , GDF$pcl == "Anthropoidea"] 
	lm.tar <- GDF$landmarks[ , , GDF$pcl == "Tarsiiformes"]
	lm.rod <- GDF$landmarks[ , , GDF$order == "Rodentia"]	
	lm.sca <- GDF$landmarks[ , , GDF$order == "Scandentia"]
	lm.str <- GDF$landmarks[ , , GDF$pcl == "Strepsirrhini"]
	lm.pri <- GDF$landmarks[ , , GDF$order == "Primates"]
	lm.hap <- GDF$landmarks[ , , GDF$HS == "Haplorhini"] 
	
	Species.lag <- Classifier$Species[Classifier$Order == "Lagomorpha"]		# assign species label used to match tip names
	Species.ple <- Classifier$Species[Classifier$PriClad == "Plesiadapiformes"]
	Species.ste <- Classifier$Species[Classifier$PriClad == "Stem_Glires"]	
	Species.ant <- Classifier$Species[Classifier$PriClad == "Anthropoidea"]
	Species.tar <- Classifier$Species[Classifier$PriClad == "Tarsiiformes"]
	Species.rod <- Classifier$Species[Classifier$Order == "Rodentia"]
	Species.sca <- Classifier$Species[Classifier$Order == "Scandentia"]
	Species.str <- Classifier$Species[Classifier$PriClad == "Strepsirrhini"]		
	Species.der <- Classifier$Species[Classifier$Order == "Dermoptera"]	
	Species.pri <- Classifier$Species[Classifier$Order == "Primates"]
	Species.hap <- Classifier$Species[Classifier$Hapstrep == "Haplorhini"]
		
	lag.tree <- drop.tip(mytree, c(Species.rod, Species.sca, Species.ste, Species.der, Species.ant, Species.ple, Species.str, Species.der, Species.tar))	# drop tips from tree for groups not of interest
	ant.tree <- drop.tip(mytree, c(Species.rod, Species.sca, Species.ste, Species.der, Species.lag, Species.ple, Species.str, Species.der, Species.tar))
	tar.tree <- drop.tip(mytree, c(Species.rod, Species.sca, Species.ste, Species.der, Species.ant, Species.ple, Species.str, Species.der, Species.lag))
	rod.tree <- drop.tip(mytree, c(Species.lag, Species.sca, Species.ste, Species.der, Species.ant, Species.ple, Species.str, Species.der, Species.tar))
	sca.tree <- drop.tip(mytree, c(Species.rod, Species.lag, Species.ste, Species.der, Species.ant, Species.ple, Species.str, Species.der, Species.tar))
	str.tree <- drop.tip(mytree, c(Species.rod, Species.sca, Species.ste, Species.der, Species.ant, Species.ple, Species.lag, Species.der, Species.tar))
	hap.tree <- drop.tip(mytree, c(Species.rod, Species.sca, Species.ste, Species.der, Species.str, Species.ple, Species.lag, Species.der))
	pri.tree <- drop.tip(mytree, c(Species.rod, Species.sca, Species.ste, Species.der, Species.lag))	
	
	dimnames(lm.lag)[[3]] <- gsub (".txt", "", Species.lag)	# assigning species names to the Y.GPA 
	dimnames(lm.ant)[[3]] <- gsub (".txt", "", Species.ant)	
	dimnames(lm.tar)[[3]] <- gsub (".txt", "", Species.tar)		
	dimnames(lm.rod)[[3]] <- gsub (".txt", "", Species.rod)	
	dimnames(lm.sca)[[3]] <- gsub (".txt", "", Species.sca)	
	dimnames(lm.str)[[3]] <- gsub (".txt", "", Species.str)	
	dimnames(lm.pri)[[3]] <- gsub (".txt", "", Species.pri)	
	dimnames(lm.hap)[[3]] <- gsub (".txt", "", Species.hap)	
	
	lm.lag.cs <- GDF$csize[GDF$order == "Lagomorpha"]		# seperate csize from common Y.gpa for each clade of interest 
	lm.ple.cs <- GDF$csize[GDF$pcl == "Plesiadapiformes"]
	lm.ste.cs <- GDF$csize[GDF$pcl == "Stem_Glires"]
	lm.ant.cs <- GDF$csize[GDF$pcl == "Anthropoidea"] 
	lm.tar.cs <- GDF$csize[GDF$pcl == "Tarsiiformes"]
	lm.rod.cs <- GDF$csize[GDF$order == "Rodentia"]	
	lm.sca.cs <- GDF$csize[GDF$order == "Scandentia"]
	lm.str.cs <- GDF$csize[GDF$pcl == "Strepsirrhini"]
	lm.pri.cs <- GDF$csize[GDF$order == "Primates"]
	lm.hap.cs <- GDF$csize[GDF$HS == "Haplorhini"]

## Confirming data is in the correct order ##
	all(lag.tree$tip.label == dimnames(lm.lag)[[3]])	# verify if names match exactly (in order)
	all(lag.tree$tip.label %in% dimnames(lm.lag)[[3]])	# verify if all your shape objects are in the phylogeny 
	all(dimnames(lm.lag)[[3]] %in% lag.tree$tip.label)	# if all tips of the tree are in your shape dataset

## DERMOPTERA and STEM GLIRES removed for Order ANOVAs due to small sample size ##
	mytree2 <- drop.tip(mytree, c(Species.der, Species.ste))		# dropping dermoptera and stem from tree
	
	class2 <- Classifier[-c(155, 154, 16, 15),]	# removing dermoptera and stem glires
	omit2 <- c(155, 154, 16, 15)
	coords.omit2 <- coords[,,-omit2]		# removing dermoptera and tarsiers  from Y.gpa
	sort(dimnames(coords.omit2)[[3]])==sort(mytree2$tip.label)		# sort and identify which names are not aligned
	
	GDF2 <- geomorph.data.frame(landmarks = coords.omit2, 
		species = class2$Species, 
		order = class2$Order,
		HS = class2$Hapstrep,
		pcl = class2$PriClad,
		rcl = class2$RodClad,
		subgroup = class2$Subgroup, 	
		figure = class2$Figure, 
		status = class2$Status,
		csize = csize[-omit2],
		phy = mytree2
		)
		
## DERMOPTERA, STEM GLIRES, and PLES removed for HS ANOVAs due to small sample size ##
	Species.ste <- Classifier$Species[Classifier$PriClad == "Stem_Glires"]	
	Species.der <- Classifier$Species[Classifier$Order == "Dermoptera"]
	Species.ple <- Classifier$Species[Classifier$PriClad == "Plesiadapiformes"]	
	mytree3 <- drop.tip(mytree, c(Species.der, Species.ple, Species.ste))		# dropping dermoptera and stem from tree
		
	class3 <- Classifier[-c(155, 154, 145, 147, 16, 15),]	# removing dermoptera and stem glires and Ples
	omit3 <- c(155, 154, 145, 147, 16, 15)
	coords.omit3 <- coords[,,-omit3]		# removing dermoptera and tarsiers  from Y.gpa
	sort(dimnames(coords.omit3)[[3]])==sort(mytree3$tip.label)		# sort and identify which names are not aligned
	
	GDF3 <- geomorph.data.frame(landmarks = coords.omit3, 
		species = class3$Species, 
		order = class3$Order,
		HS = class3$Hapstrep,
		pcl = class3$PriClad,
		rcl = class3$RodClad,
		subgroup = class3$Subgroup, 	
		figure = class3$Figure, 
		status = class3$Status,
		csize = csize[-omit3],
		phy = mytree3
		)

### RUNNING Procrustes ANOVA - Order ###
	PANOVA.ord <- procD.lm(landmarks~order, data = GDF2, iter = 9999, RRPP = TRUE)
		summary(PANOVA.ord)
	PW.ord <- pairwise(PANOVA.ord, groups = GDF2$order, covariate = NULL)
		summary(PW.ord)
			
### RUNNING Procrustes ANOVA - Hap/Strep ###
	PANOVA.HS <- procD.lm(landmarks~HS, data = GDF3, iter = 9999, RRPP = TRUE)
		summary(PANOVA.HS)
	PW.HS <- pairwise(PANOVA.HS, groups = GDF3$HS, covariate = NULL)
		summary(PW.HS, stat.table = TRUE)
		
### RUNNING Procrustes ANOVA - Ant/Tar ###
	PANOVA.pcl <- procD.lm(landmarks~pcl, data = GDF3, iter = 9999, RRPP = TRUE)
		summary(PANOVA.pcl)
	PW.pcl <- pairwise(PANOVA.pcl, groups = GDF3$pcl, covariate = NULL)

## Overall Allometry ##
	common.allo <- procD.lm(GDF$landmarks~log(GDF$csize),data = GDF,iter = 9999) 
		summary(common.allo)
	pgls.common.allo <- procD.pgls(GDF$landmarks~log(GDF$csize), phy = mytree, data = GDF, iter = 9999)	
		anova(pgls.common.allo)

## Clade ANOVAs (linear model and PGLS) of shape and size using clade specific procrustes transformations ##
	rawcoords <- Y.gpa$coords[,,match(mytree$tip.label, dimnames(Y.gpa$coords) [[3]] ) ] #rearrange data
		# need the raw coords to apply clade specific transformations
	
## Allometry Haplorhini - clade specific ##
	coords.hap <- rawcoords[ , , GDF$HS == "Haplorhini"]
	Y.gpa.hap <- gpagen(coords.hap, curves = sliders)	
	
	names(Y.gpa.hap$Csize) = Species.hap								
	dimnames(Y.gpa.hap$coords)[[3]] <- gsub (".txt", "", Species.hap)	
	gdf.hap <- geomorph.data.frame(lmpla = Y.gpa.hap$coords, Csize.ord = Y.gpa.hap$Csize, species.ord = Species.hap)
	
	fit.unique.hap <- procD.lm(Y.gpa.hap$coords~log(Y.gpa.hap$Csize), data = gdf.hap, iter = 9999, RRPP = TRUE) 
		summary(fit.unique.hap)

## Allometry Anthropoidea - clade specific ##
	coords.ant <- rawcoords[ , , GDF$pcl == "Anthropoidea"]
	Y.gpa.ant <- gpagen(coords.ant, curves = sliders)	
	
	names(Y.gpa.ant$Csize) = Species.ant								
	dimnames(Y.gpa.ant$coords)[[3]] <- gsub (".txt", "", Species.ant)	
	gdf.ant <- geomorph.data.frame(lmpla = Y.gpa.ant$coords, Csize.ord = Y.gpa.ant$Csize, species.ord = Species.ant)
	
	fit.unique.ant <- procD.lm(Y.gpa.ant$coords~log(Y.gpa.ant$Csize), data = gdf.ant, iter = 9999, RRPP = TRUE) 
		summary(fit.unique.ant)

## Allometry Lagomorpha - clade specific ##
	coords.lag <- rawcoords[ , , GDF$order == "Lagomorpha"]
	Y.gpa.lag <- gpagen(coords.lag, curves = sliders)	
	
	names(Y.gpa.lag$Csize) = Species.lag								
	dimnames(Y.gpa.lag$coords)[[3]] <- gsub (".txt", "", Species.lag)	
	gdf.lag <- geomorph.data.frame(lmlag = Y.gpa.lag$coords, Csize.ord = Y.gpa.lag$Csize, species.ord = Species.lag)
	
	fit.unique.lag <- procD.lm(Y.gpa.lag$coords~log(Y.gpa.lag$Csize),data = gdf.lag,iter = 9999, RRPP = TRUE) 
		summary(fit.unique.lag)

## Allometry Rodentia - clade specific ##
	coords.rod <- rawcoords[ , , GDF$order == "Rodentia"]
	Y.gpa.rod <- gpagen(coords.rod, curves = sliders)	

	names(Y.gpa.rod$Csize) = Species.rod								
	dimnames(Y.gpa.rod$coords)[[3]] <- gsub (".txt", "", Species.rod)	
	gdf.rod <- geomorph.data.frame(lmrod = Y.gpa.rod$coords, Csize.ord = Y.gpa.rod$Csize, species.ord = Species.rod)
	
	fit.unique.rod <- procD.lm(Y.gpa.rod$coords~log(Y.gpa.rod$Csize), data = gdf.rod, iter = 9999, RRPP = TRUE) 
		summary(fit.unique.rod)


## Allometry Scandentia - clade specific ##
	coords.sca <- rawcoords[ , , GDF$order == "Scandentia"]
	Y.gpa.sca <- gpagen(coords.sca, curves = sliders)	
	
	names(Y.gpa.sca$Csize) = Species.sca								
	dimnames(Y.gpa.sca$coords)[[3]] <- gsub (".txt", "", Species.sca)	
	gdf.sca <- geomorph.data.frame(lmsca = Y.gpa.sca$coords, Csize.ord = Y.gpa.sca$Csize, species.ord = Species.sca)
	
	fit.unique.sca <- procD.lm(Y.gpa.sca$coords~log(Y.gpa.sca$Csize), data = gdf.sca, iter = 9999, RRPP = TRUE) 
		summary(fit.unique.sca)

## Allometry Strepsirrhini - clade specific ##
	coords.str <- rawcoords[ , , GDF$pcl == "Strepsirrhini"]
	Y.gpa.str <- gpagen(coords.str, curves = sliders)	
	
	names(Y.gpa.str$Csize) = Species.str								
	dimnames(Y.gpa.str$coords)[[3]] <- gsub (".txt", "", Species.str)	
	gdf.str <- geomorph.data.frame(lmstr = Y.gpa.str$coords, Csize.ord = Y.gpa.str$Csize, species.ord = Species.str)
	
	fit.unique.str <- procD.lm(Y.gpa.str$coords~log(Y.gpa.str$Csize), data = gdf.str, iter = 9999, RRPP = TRUE) 
		summary(fit.unique.str)
	
## Homogeneity of Slopes Test - HS ##
	fit.unique.HS <- procD.lm(landmarks~log(GDF3$csize)*HS,data = GDF3,iter = 9999, RRPP = TRUE) 
		summary(fit.unique.HS)
	fit.common.HS  <- procD.lm(landmarks~log(GDF3$csize)+HS,data = GDF3,iter = 9999, RRPP = TRUE)
		summary(fit.common.HS)
	fits.HS<-anova(fit.common.HS, fit.unique.HS, print.progress = FALSE)
	fits.HS
	
	PW.allo.HS <- pairwise(fit = fit.unique.HS, fit.null = fit.common.HS, groups = GDF3$HS, covariate = GDF3$csize)
		summary(PW.allo.HS)
		summary(PW.allo.HS, test.type = "DL", confidence = 0.95, stat.table = TRUE)	
		summary(PW.allo.HS, test.type = "VC", angle.type = "deg", stat.table = TRUE)	

### Overall Phylogenetic Signal in Shape ###
	physig <- physignal(A = GDF$landmarks, phy = mytree,iter = 999)
		summary(physig)	
		
## Clade Specific Physignals in Shape from common y.gpa ##
	phy.lm.ant <- physignal(A = lm.ant,phy = ant.tree,iter = 999)
		summary(phy.lm.ant)
	phy.lm.lag <- physignal(A = lm.lag,phy = lag.tree,iter = 999)
		summary(phy.lm.lag)	
	phy.lm.rod <- physignal(A = lm.rod,phy = rod.tree,iter = 999)
		summary(phy.lm.rod)
	phy.lm.sca <- physignal(A = lm.sca,phy = sca.tree,iter = 999)
		summary(phy.lm.sca)
	phy.lm.str <- physignal(A = lm.str,phy = str.tree,iter = 999)
		summary(phy.lm.str)
	phy.lm.pri <- physignal(A = lm.pri,phy = pri.tree,iter = 999)
		summary(phy.lm.pri)
	phy.lm.tar <- physignal(A = lm.tar,phy = tar.tree,iter = 999)
		summary(phy.lm.tar)

## Evolutionary models - ORDER for oum
# tree with regimes mapped onto the branches #
	regimes <- setNames(GDF$order, GDF$species)  # clade assignments for each species
	tree_map <- make.simmap(mytree, regimes, model = "ER", nsim = 1) #create tree with mapped clades
	plotSimmap(tree_map)
	
## Evaluateing different evolutionary model ## 
	bm_model <- mvBM(tree = mytree, data = mtx, model = "BM1", scale.height = TRUE, method = "sparse")	#unique adaptive optima per trait (PC)
	ou1_model <- mvOU(tree = mytree, data = mtx, model = "OU1", scale.height = TRUE,method = "sparse")	#single optima
	eb_model <- mvEB(tree = mytree, data = mtx, scale.height = TRUE,method = "sparse", param = list(decomp = "cholesky", root = TRUE))
	oum_model <- mvOU(tree = tree_map, data = mtx, model = "OUM", scale.height = TRUE,method = "sparse", param = list(decomp = "cholesky", root = TRUE))
	bmtrend_model<- mvBM(tree = mytree, data = mtx, scale.height = TRUE,model = "BM1", param = list(trend = TRUE))	#unique adaptive optima per trait (PC)

# saving these models in case I need to open them again. 
	#save(bm_model, ou1_model, eb_model, oum_model, bmtrend_model, file = "evolutionary_models_order.RData")
	#load("evolutionary_models_order.RData")

# AICc table #
	AICc_bm <- bm_model$AICc
	AICc_ou1 <- ou1_model$AICc
	AICc_eb  <- eb_model$AICc
	AICc_oum  <- oum_model$AICc
	AICc_bmt  <- bmtrend_model$AICc
	
# Combine for comparison
	aic_table <- data.frame(
		Model = c("BM", "OUM", "OU1", "EB", "BM_trend"),
		AICc  = c(AICc_bm, AICc_oum, AICc_ou1, AICc_eb, AICc_bmt))
	aic_table$deltaAICc <- aic_table$AICc - min(aic_table$AICc)
	aic_table$weights <- exp(-0.5 * aic_table$deltaAICc)
	aic_table$weights <- aic_table$weights / sum(aic_table$weights)
	print(aic_table)

# Examining alpha and half life for the OU models
# Extract alpha matrix
	alpha_matrix <- oum_model$alpha
	alpha_matrix

# Compute half-lives for each trait (diagonal only)
	halflives <- log(2) / diag(alpha_matrix)	# calcualte the natural log of 2 divided by the alpha level (obtained from the diagonal of the alpha matrix from ou1_model$alpha
	names(halflives) <- colnames(alpha_matrix)  # Optional: name by trait
	halflives

## Assessing evolutionary model results against simulations ##
# need to create batches of simulated data first. See file Creating-simulation-batches.r 
# retreiving saved batches
	batch1 <- readRDS("sim_results_batch1_with_alpha_theta.rds")
	batch2 <- readRDS("sim_results_batch2_with_alpha_theta.rds")
	batch3 <- readRDS("sim_results_batch3_with_alpha_theta.rds")
	batch4 <- readRDS("sim_results_batch4_with_alpha_theta.rds")
	batch5 <- readRDS("sim_results_batch5_with_alpha_theta.rds")
	batch6 <- readRDS("sim_results_batch6_with_alpha_theta.rds")

# Combine simulations batches into one list
	all_results <- c(batch1, batch2, batch3, batch4, batch5, batch6)	# Combine batches into one list
	sim_results_df <- do.call(rbind, all_results)	# Convert to data frame for analysis

# Organizing the data 
	model_names <- c("BM", "OU1", "OUM", "EB")					# Define expected model names
	aicc_list <- lapply(all_results, function(res) res$AICc)	# Extract AICc tables from all simulation results
	aicc_df <- do.call(rbind, aicc_list)						# Combine into one data frame
	best_models <- apply(aicc_df, 1, function(x) names(which.min(x)))	# Find best model per row (lowest AICc)

# Calculate the deltaAICc for each row
	delta_aicc_list <- apply(aicc_df, 1, function(x) x - min(x))
	delta_aicc_df <- as.data.frame(t(delta_aicc_list))
	colnames(delta_aicc_df) <- model_names

	best_model_counts <- table(factor(best_models, levels = model_names))	#Count how often each model is best

# Count how often each model is within deltaAICc < 2
	within2_counts <- sapply(model_names, function(model) {
		sum(delta_aicc_df[[model]] < 2, na.rm = TRUE)
	})

# Combine into a summary table
	summary_df <- data.frame(
		Model = model_names,
		SelectedAsBest = as.integer(best_model_counts),
		DeltaAICcUnder2 = within2_counts
	)
	print(summary_df)

## PCA ##
	PCA <- gm.prcomp(GDF$landmarks)

## RUNNING PCA - GGPLOT ##
	PCScore <- PCA$x
	PCi <- data.frame(PCScore, figure = Classifier$Figure, status = Classifier$Status) # convert the data to a dataframe so that I can use ggplot2 
	# to make aesthetic changes	
		
	cols <- c("#F0E442", "#0072B2", "#CC0000", "#009E73", "#CC79A7", "#D55E00", "#000066", "#117733", "#99CCFF")
	
	shapes <- c(16, 17)		

	ggplot(PCi, aes(x = Comp1, y = Comp2, color = figure, shape = status)) +
		geom_hline(yintercept = 0, color = "gray85", size = 0.25, linetype = "dashed") +
		geom_vline(xintercept = 0, color = "gray85", size = 0.25, linetype = "dashed") +
		geom_point(size = 2, alpha = 0.8) +  # Points on top of the gridlines
			scale_color_manual(values = cols) + #your colors here
		labs(x = "PC1 (54.13%)", y = "PC2 (7.43%)") +
		theme_minimal(base_size = 12) +
		theme(
			axis.text.x = element_text(size = 8, colour = "black"),  # font size 8 on x-axis
			axis.text.y = element_text(size = 8, colour = "black"),  # font size 8 on y-axis
			axis.title = element_text(size = 10),  # font size for axis titles
			legend.title = element_blank(),
			legend.text = element_text(size = 7, margin = margin(t = 0.01)),
			legend.position = "top",
			legend.direction = "horizontal",
			legend.background = element_blank(),  # Remove background around legend
			legend.box.background = element_blank(),  # Remove border around legend box
			legend.key = element_blank(),  # Remove the box behind the legend symbols
			legend.key.height = unit(0.5, "line"),
			legend.spacing.x = unit(0.001, "cm"),
			legend.spacing.y = unit(0.05, "cm"),  # Reduce vertical space between legend items
			legend.margin = margin(t = 0, b = 0),  # Reduce margins above and below legend
			legend.box.spacing = unit(0.1, "cm"),  # Reduce space between legend boxes
			axis.ticks = element_blank(),  # No axis ticks
			panel.grid.major = element_blank(),  # Remove major gridlines
			panel.grid.minor = element_blank(),  # Remove minor gridlines
			panel.border = element_rect(color = "black", fill = NA, size = 0.35),  # Add box around the plot
		)
	ggsave("PCA-EG-GM-ggplot-OCT.pdf", plot = last_plot(), width = 6.5, height = 6.5)


## RUNNING PCA - GGPLOT - ED Figure ##
	PCScore <- PCA$x
	PCi <- data.frame(PCScore, figure = Classifier$RodClad, status = Classifier$Status) # convert the data to a dataframe so that I can use ggplot2 
	# to make aesthetic changes	
		
	cols <- c("#CC79A7", "#F0E442", "#CC0000", "#009E73", "#0072B2", "#D55E00", "#666666", "#000066")
	
	shapes <- c(16, 17)		

	ggplot(PCi, aes(x = Comp1, y = Comp2, color = figure, shape = status)) +
		geom_hline(yintercept = 0, color = "gray85", size = 0.25, linetype = "dashed") +
		geom_vline(xintercept = 0, color = "gray85", size = 0.25, linetype = "dashed") +
		geom_point(size = 2, alpha = 0.8) +  # Points on top of the gridlines
			scale_color_manual(values = cols) + #your colors here
		labs(x = "PC1 (54.13%)", y = "PC2 (7.43%)") +
		theme_minimal(base_size = 12) +
		theme(
			axis.text.x = element_text(size = 8, colour = "black"),  # font size 8 on x-axis
			axis.text.y = element_text(size = 8, colour = "black"),  # font size 8 on y-axis
			axis.title = element_text(size = 10),  # font size for axis titles
			legend.title = element_blank(),
			legend.text = element_text(size = 7, margin = margin(t = 0.01)),
			legend.position = "top",
			legend.direction = "horizontal",
			legend.background = element_blank(),  # Remove background around legend
			legend.box.background = element_blank(),  # Remove border around legend box
			legend.key = element_blank(),  # Remove the box behind the legend symbols
			legend.key.height = unit(0.5, "line"),
			legend.spacing.x = unit(0.001, "cm"),
			legend.spacing.y = unit(0.05, "cm"),  # Reduce vertical space between legend items
			legend.margin = margin(t = 0, b = 0),  # Reduce margins above and below legend
			legend.box.spacing = unit(0.1, "cm"),  # Reduce space between legend boxes
			axis.ticks = element_blank(),  # No axis ticks
			panel.grid.major = element_blank(),  # Remove major gridlines
			panel.grid.minor = element_blank(),  # Remove minor gridlines
			panel.border = element_rect(color = "black", fill = NA, size = 0.35),  # Add box around the plot
		)
	ggsave("PCA-EG-GM-ggplot-OCT-ED.pdf", plot = last_plot(), width = 6.5, height = 6.5)

## Surface warps for PCA ##
    ref <-mshape(Y.gpa$coords)	# get coords for the mean shape from the transformed landmark matrix
    var <- Y.gpa[["coords"]]
    avg <-mshape(var)			# calculate the mean shape
    findMeanSpec(var)			# identify species closest to mean

    mean.ply <- read.ply("Paraxerus_cepapi.ply", ShowSpecimen=FALSE)    # load the .ply for the mean species
    mean.coords <- coords.all[,,112]									# get the untransformed coordinates for the mean specimen/species (38 is the sequence number for the mean species (i.e. Paraxerus))
    ygpa.mc <- Y.gpa$coords[,,112]										# get transformed coords (from Y.gpa) for the mean specimen/species
       
    averagemesh <- warpRefMesh(mean.ply, mean.coords, avg, color=NULL, centered=TRUE)	# create a mesh of the average shape
   
    PC1min <- PCA$shapes$shapes.comp1$min	# identify the coords for the min of PC1 (comp1)
	PC1max <- PCA$shapes$shapes.comp1$max
	PC2min <- PCA$shapes$shapes.comp2$min
	PC2max <- PCA$shapes$shapes.comp2$max
    
	PC1minwarp <- plotRefToTarget(M1 = ygpa.mc, M2 = PC1min, mesh = averagemesh, method = "surface", color = "royalblue3")	
		#rgl.snapshot( "PC1minwarp.png", fmt = "png", top = TRUE )
	PC1maxwarp <- plotRefToTarget(M1 = ygpa.mc, M2 = PC1max, mesh = averagemesh, method = "surface", color = "royalblue3")	
		#rgl.snapshot( "PC1maxwarp.png", fmt = "png", top = TRUE )
	PC2minwarp <- plotRefToTarget(M1 = ygpa.mc, M2 = PC2min, mesh = averagemesh, method = "surface", color = "royalblue3")	
		#rgl.snapshot( "PC2minwarp.png", fmt = "png", top = TRUE )
	PC2maxwarp <- plotRefToTarget(M1 = ygpa.mc, M2 = PC2max, mesh = averagemesh, method = "surface", color = "royalblue3")	
		#rgl.snapshot( "PC2maxwarp.png", fmt = "png", top = TRUE )

## Setting up data for SearchShift ##
	PCA2<-as.data.frame(PCA$x)
	PCA2<-add_column(PCA2, species = GDF$species)
	mytree$tip.label==rownames(PCA2)	# make sure row names == tip labels

###### RRphylo - Search Shift ######
## RRPHYLO Shape - clade - Search Shift ## 
	rrphylo.shape<-RRphylo(mytree, y=as.matrix(PCA2[,1:4]))	# 95% of variance captured by comp 24	
		print(rrphylo.shape)
		#write.csv(rrphylo.shape[["rates"]], "evo.rates.csv")
	rrphylo.ss.cl<-search.shift(rrphylo.shape, status.type = "clade", state = NULL, nrep = 9999)
		rrphylo.ss.cl[["all.clades"]]
		rrphylo.ss.cl[["single.clades"]]

	pdf("Search.Shift-Aug27.pdf", width = 4.5, height = 8.5)
	plotSS.cl <- plotShift(rrphylo.shape, rrphylo.ss.cl, state = as.matrix(PCA2[,1:4]))
	plotSS.cl$plotClades(tree.args=list(no.margin=TRUE,type="phylogram", edge.width=1, edge.color = "black", tip.label=NULL, cex=0.3, use.edge.length=TRUE),
		symbols.args=list(fg=NA,bg=c(pos="#339966",neg="#FF6666")))
	dev.off() 

## Disparity Through Time (dispRity) - All species ##	
# Making the data matrix #	
	PCA_dtt<-as.data.frame(PCA$x)
	PCA_dtt<-PCA_dtt[order(rownames(PCA_dtt)),]		# puts data into disparity matrix
	PCA_dtt<-add_column(PCA_dtt, species = spnames$Species)
	mPCA<-PCA_dtt[match(mytree$tip.label,rownames(PCA_dtt)),][1:4] # making a PCA file which matches sequence in phylogeny - should already be matching 
	mtx<-as.matrix(mPCA)

# Calculate average squared pairwise distance (dispRity) #
	average.sq<-function(X) mean(pairwise.dist(X)^2)	#The average squared pairwise distance metric (also used in geiger::dtt)
	avg_sq_dist <- apply(mtx, 1, average.sq)

# DTT with average squared pairwise distance (dispRity) # 	
	dispR <- dtt.dispRity(
		data = mtx,
		metric = average.sq,       
		tree = mytree,
		nsim = 1000,
		model = "BM",
		alternative = "two-sided",
		calculateMDIp = TRUE,
		scale.time = TRUE
	)
	dispR
	dispR$MDI   # Single number summarizing disparity difference from simulations
	# Negative MDI = observed disparity below simulations.

## DTT (dispRity) plotting ##	
	max_age <- 78

# base plot (suppress x-axis so we can customize)
	pdf("DTT-Aug27-.pdf", width = 9, height = 6)
	plot(dispR, 
		col = c("#0000CC","#99CCFF","#6699FF"),
		ylab = "Average squared pairwise distance", 
		xlab = "",
		xaxt = "n", 
		yaxt = "s",
		main = "Disparity Through Time - Endocranial Shape in Euarchontoglires"
	)

# Epochs
	epochs <- data.frame(
		name  = c("Late Cretaceous","Paleocene","Eocene","Oligocene", "Miocene","Pliocene","Pleistocene","Holocene"),
		start = c(78, 66.0, 56.0, 33.9, 23.03, 5.333, 2.58, 0.0117), # Ma
		end   = c(66.0,56.0, 33.9, 23.03, 5.333, 2.58, 0.0117, 0.0)  # Ma
	)

# Convert Ma to relative dispRity x-coordinates
	epochs$xleft  <- (max_age - epochs$start) / max_age
	epochs$xright <- (max_age - epochs$end)   / max_age
	epochs$xmid   <- (epochs$xleft + epochs$xright) / 2

	cols <- c("#f0f4ff80","#e8f7ff80","#e6ffe680","#fff6e680","#ffe8f080","#f3ffe680","#e8f0ff80","#fff0e680")
	usr <- par("usr")

# Draw rectangles for epochs
	for(i in seq_len(nrow(epochs))){
		rect(epochs$xleft[i], usr[3], epochs$xright[i], usr[4],
		col = cols[i], border = NA)
	}

# Replot DTT lines on top so they’re not hidden
	plot(dispR,
		col = c("#0000CC","#FFCCFF","#CC99CC"),
		ylab = "Average squared pairwise distance", 
		xlab = "",
		xaxt = "n", yaxt = "s", add = FALSE
	)

# axis 
	axis(1,
		at = seq(0, 1, by = 5/max_age),   # relative positions
		labels = seq(max_age, 0, by = -5) # labels in Ma
	)
	mtext("Time (Ma)", side = 1, line = 2.5)
	axis(1, at = epochs$xmid, labels = FALSE, tick = FALSE)	# Add epoch labels under the axis
	mtext(epochs$name, side = 1, at = epochs$xmid, line = 4.5, cex = 0.75)

	dev.off()

## Broken Stick Model (Wilson et al., 2023; https://doi.org/10.1038/s41467-023-38365-0) ##
	ev<-PCA$sdev^2
	
	pdf("Broken-stick-model.pdf", width = 9, height = 9)
	bsm <- function(ev) { 
		# Broken stick model (MacArthur 1957)
		n = length(ev)
			bsm = data.frame(j=seq(1:n), p=0)
		bsm$p[1] = 1/n
		for (i in 2:n) bsm$p[i] = bsm$p[i-1] + (1/(n + 1 - i))
		bsm$p = 100*bsm$p/n
		# Plot eigenvalues and % of variation for each axis
		op = par(mfrow=c(2,1),omi=c(0.1,0.3,0.1,0.1), mar=c(1, 1, 1, 1))
		barplot(ev, main="Eigenvalues", col="lightskyblue", las=2)
		abline(h=mean(ev), col="red")
		legend("topright", "Average eigenvalue", lwd=1, col=2, bty="n")
		barplot(t(cbind(100*ev/sum(ev), bsm$p[n:1])), beside=TRUE, 
			main="% variation", col=c("lightskyblue",2), las=2)
		legend("topright", c("% eigenvalue", "Broken stick model"), 
			pch=15, col=c("lightskyblue",2), bty="n")
		par(op)
	}
	bsm(ev)	# suggests comp 4 is the limit 	
	dev.off() 