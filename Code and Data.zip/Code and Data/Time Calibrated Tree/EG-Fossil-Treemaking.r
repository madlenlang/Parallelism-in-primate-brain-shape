library(phytools) 
library(paleotree)
library(dispRity)
library(phangorn)

setwd("D:/Lang - GMM Endocast Project/Fossil Paper/Time-Tree")

## CREATING TREE FROM VERTLIFE FILE ## do not run if you already have the tree (it might change the order of the taxa)
	#my.tree <- read.nexus("output.nex")											# load file with vertlife.org set of trees for extant only taxa
	#mytree <- maxCladeCred(my.tree, tree = TRUE, part = NULL, rooted = TRUE)		# gives Maximum clade credibility tree (selects tree with highest clade support from list)
	#write.nexus(mytree, file = "mytree.nex", translate = TRUE)

## Rooting MCC tree to then add fossils in Mequite ##
	#mytree1 <- read.nexus("mytree-original.nex")			# loading in extant only tree
	#tipAges <- cbind(c("Ptilocercus_lowii","Ochotona_collaris"), c(0,0))	# calcualted time between these two taxa to get root age (because they are extant time = 0)
	#TimeTree <- setRootAge(mytree1,tipAges)		# set root age
	#TimeTree$root.time		# check root age					

	#treeage <- tree.age(mytree, age=76.92149, order="past", fossil=TRUE, digits=3)		# calculate ages for nodes within the tree	

## add fossils in MESQUITE ##

## READING THE MESQUITE TREE ##
	mytree <- read.nexus("tree-mes.nex")	

# Sorting out node ages for cal3 node.mins #
	nodetree<-makeNodeLabel(mytree, method = "number")	# assign nodelabels to the phy
	plot(nodetree, show.node.label = TRUE, cex = 0.15, edge.width = 0.2)	# plot the phy object
	# Creating a node age file ("Node-Legend.csv"): open tiptreemes.nex in Figtree and show node ages. Create an excel file with two columns, 
	# one corresponding to node label (from the plot(nodetree...) above) and the other with the age at that node. 
	# Nodes with no age in the .csv should have a "NA". 
	
# Cleaning node ages - removing node ages that may still be from the extant only tree
	mytree$node.label <- NULL
	
	nodeages<-read.csv("Node-Legend.csv",header=TRUE)
	nodeDates<-c(nodeages$Age)	# Age2 has no node age for Hap/Strep only as a polytomy was being created.
	
#### Make a calibrated tree 
#### bin_cal3TimePaleoPhy method 
# taxa range for age
	taxon.times<-read.csv("taxon_times-5interval.csv",row.names=1)	# what time bins each taxon is in 
	int.times<-read.csv("int_times-5interval.csv",row.names=1)		# what are the time intervals for each bin (5MA intervals)
	fossil.range<-list(int.times,taxon.times)

#bin_cal3TimePaleoPhy method
	likFun<-make_durationFreqDisc(fossil.range)
	spRes<-optim(parInit(likFun),likFun,lower=parLower(likFun),upper=parUpper(likFun),
		method="L-BFGS-B",control=list(maxit=1000000))

#sampling PROBABILITY per bin
	sProb <- spRes[[1]][2]

#calculate meanInt. We need to use an average int.length (intervals not the same duration)
	intLength<--apply(fossil.range[[1]],1,diff)
		hist(intLength)
	meanInt <--mean(apply(fossil.range[[1]], 1, diff)) # close to 1.8 Million years
	sRate <- sProb2sRate(sProb,int.length = meanInt)
	
# we also need extinction rate and branching rate (see above)
# need to divide by int.length...
	divRate <- spRes[[1]][1]/meanInt

# calibrated tree
	mytree1 <- bin_cal3TimePaleoPhy(
		nodetree, 
		fossil.range, 				# data on the FAD and LAD of fossils
		FAD.only = TRUE,            # required when not using point-occurrences
		dateTreatment = "firstLast",
		root.max = 76.92149,
		brRate = divRate, 
		extRate = divRate,
		sampRate = sRate, 
		ntrees = 1000, 
		node.mins = nodeDates,       # node ages from file
		verboseWarnings = TRUE,
		tolerance = 1,  
		step.size = 0.0001,  # Reducing the step size of increments used in zipper algorithm to assign node ages reduces the number of brlens = 0. Smaller step size will take more time to compute.
		plot = FALSE
	)

# How many trees in bin_cal3TimePaleoPhy() have brlen = 0 
	any_zero_length <- sapply(mytree1, function(tree) any(tree$edge.length == 0))
	any(any_zero_length)  # TRUE if any tree has at least one zero-length edge
	which(any_zero_length)  # which trees have trees with edge.length == 0
	
## Drop any trees from the list which contain edge lengths that = 0 (can happen when using the bin_cal3TimePaleoPhy function with larger step sizes)
	nonzero_trees_idx <- which(sapply(mytree1, function(tr) all(tr$edge.length > 0)))	# Find trees with all branches > 0
	mytrees <- mytree1[nonzero_trees_idx]	# Subset the set of trees to remove trees with zero-length branches

# Confirming the trees all have the same topology (important for the everaging of branchlengths)
# Pick the first tree as the reference topology
	ref_tree <- mytrees[[1]]	

# Compare all other trees to the reference
	topology_check <- sapply(mytrees, function(tr) {
		isTRUE(all.equal.phylo(ref_tree, tr, use.edge.length = FALSE))
	})
	table(topology_check)  # TRUE means identical topology which is what we need to average branches

# Averaging the branch lengths across all trees
	library(progress)

# Extract edge lengths from all trees into a matrix
# Each row = a tree; each column = a branch (edge)
	edge_matrix <- do.call(rbind, lapply(mytrees, function(tr) tr$edge.length))

# Calculate the mean edge length for each branch
	avg_edge_lengths <- colMeans(edge_matrix, na.rm = TRUE)

# Create a new tree using the reference topology and assign averaged edge lengths
	avg_tree <- ref_tree
	avg_tree$edge.length <- avg_edge_lengths

# Making sure everything has worked properly 
	stopifnot(!any(is.na(avg_tree$edge.length)))	# Ensure no NA values

# Plot the averaged tree
	plot(avg_tree, main = "Manually Averaged Tree (Mean Edge Lengths)")

# Save averaged tree
	write.nexus(avg_tree, file = "avg_tree_manual_mean-1000.nex")

